# from pymongo import MongoClient
# from bson.objectid import ObjectId

# class AnimalShelter(object):
#     """CRUD operations for Animal collection in MongoDB"""
    
#     def __init__(self):
#         self.client = MongoClient('mongodb://%s:%s@%s:%d' % ('accuser', 'animallover', 'nv-desktop-services.apporto.com', 31160))
#         self.database = self.client['AAC']
#         self.collection = self.database['%s' % ('animals')]

# # Method for C in CRUD
#     def create(self, data):
#         if data is not None:
#             insert = self.database.animals.insert(data)
#         else:
#             raise Exception("Data parameter is empty")
        
# #Method for R in CRUD
#     def read(self, searchData):
#         if searchData:
#             data = self.database.animals.find(searchData, {"_id": False})
#         else:
#             data = self.database.animals.find({}, {"_id": False})
#         return data
        
#Method for U in CRUD
#     def update(self, searchData, updateData):
#         if searchData is not None:
#             result = self.database.animals_many(searchData, { "$set": updateData})
#         else:
#             return "{}"
#         return result.raw_result
    
# #Method for D in CRUD
#     def delete(self, deleteData):
#         if deleteData is not None:
#             result = self.database.animals.delete_many(deleteData)
#         else:
#             return "{}"
#         return result.raw_result



from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'animallover'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31160
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary            
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
#Method for R in CRUD
    def read(self, searchData):
        if searchData:
            data = self.database.animals.find(searchData, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
        return data
        
        
#Method for U in CRUD
    def update(self, searchData, updateData):
        if searchData is not None:
            result = self.database.animals_many(searchData, { "$set": updateData})
        else:
            return "{}"
        return result.raw_result
    
#Method for D in CRUD
    def delete(self, deleteData):
        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
        else:
            return "{}"
        return result.raw_result